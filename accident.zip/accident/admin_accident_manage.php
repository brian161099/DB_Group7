<!DOCTYPE html>
<html lang="zh-Hant">

<head>
    <meta charset="UTF-8">
    <title>事故資料管理</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 引入CSS樣式 -->
    <link rel="stylesheet" href="style.css">
    <!-- 引入jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <h2 style="position: absolute; top: 6px; left: 10px; font-size: 30px;">事故資料管理 </h2>
    <div id="navbar">
        <div id="user-info" style="position: fixed; top: 5px; right: 5px;">
            <img src="figure/admin.png" alt="User" id="user-avatar" style="display: block; width: 60px; height: auto; margin: 0 auto;">
            <button onclick="window.location='index.php'" style="display: block; width: 80px; margin: 10px auto; text-align: center;">Log out</button>
        </div>
    </div>

    <div id="search-section" style="text-align: center; margin-top: 150px;">
        <label for="hotspot-id" style="font-size: 25px;">輸入HotspotID查詢：</label>
        <input type="text" id="hotspot-id" name="hotspot-id" style="font-size: 25px; margin-right: 10px;">
        <button id="search-button" style="font-size: 25px;">送出查詢</button>
    </div>

    <hr style="border: none; border-top: 5px solid rgba(0, 0, 0, 0.5); margin-top: 25px;">

    <style>
        /* Add grid lines to the table */
        #results-table {
            border-collapse: collapse;
            margin: 0 auto;
            /* Center the table */
        }

        #results-table th,
        #results-table td {
            border: 1px solid black;
            padding: 16px;
            /* Increase cell padding */
            text-align: center;
            /* Center the cell content */
            width: calc(100% / 6);
            /* Divide the width equally among 6 cells */
        }
    </style>

    <div id="results-section">
        <table id="results-table">
            <!-- 表格頭部 -->
            <thead>
                <tr>
                    <th>HotspotID</th>
                    <th>UserID</th>
                    <th>Critical</th>
                    <th>Timestamp</th>
                    <th>座標</th>
                    <th>刪除</th>
                </tr>
            </thead>
            <!-- 表格數據填充在這裡 -->
            <tbody id="table-body">
                <!-- 由PHP查詢結果動態生成 -->
            </tbody>
        </table>
    </div>
    <script>
        // 使用jQuery處理查詢按鈕的點擊事件
        $('#search-button').click(function() {
            var hotspotId = $('#hotspot-id').val();
            $.post('search_hotspot.php', {
                hotspot_id: hotspotId
            }, function(data) {
                $('#table-body').html(data);
            });
        });
    </script>
</body>

</html>

<?php
// 假設已經建立了資料庫連接
$db = new PDO('pgsql:host=localhost;dbname=Test6', 'postgres', '12345');

// 從POST請求中獲取HotspotID
$hotspotId = $_POST['hotspot_id'];

// 安全地構建SQL查詢，防止SQL注入
$query = $db->prepare("SELECT * FROM hotspots WHERE hotspot_id = ?");
$query->execute([$hotspotId]);

// 獲取查詢結果
$results = $query->fetchAll(PDO::FETCH_ASSOC);

// 將結果以HTML表格行的形式輸出
foreach ($results as $row) {
    echo "<tr>";
    echo "<td>{$row['hotspot_id']}</td>";
    echo "<td>{$row['user_id']}</td>";
    echo "<td>{$row['critical']}</td>";
    echo "<td>{$row['timestamp']}</td>";
    echo "<td>{$row['coordinates']}</td>";
    echo "<td><button class='delete-button' data-id='{$row['hotspot_id']}'>刪除</button></td>";
    echo "</tr>";
}
?>