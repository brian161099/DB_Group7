<!DOCTYPE html>
<html lang="zh-Hant">

<head>
    <meta charset="UTF-8">
    <title>交通氣象資料管理</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 引入CSS樣式 -->
    <link rel="stylesheet" href="style.css">
    <!-- 引入jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <h2 style="position: absolute; top: 6px; left: 10px; font-size: 30px;">交通氣象資料管理 </h2>
    <div id="navbar">
        <div id="user-info" style="position: fixed; top: 5px; right: 5px;">
            <img src="figure/admin.png" alt="User" id="user-avatar" style="display: block; width: 60px; height: auto; margin: 0 auto;">
            <button onclick="window.location='index.php'" style="display: block; width: 80px; margin: 10px auto; text-align: center;">Log out</button>
        </div>
    </div>

    <div id="search-section" style="text-align: center; margin-top: 150px;">
        <label for="user-id" style="font-size: 25px;">輸入HotspotID查詢：</label>
        <input type="text" id="user-id" name="user-id" style="font-size: 25px; margin-right: 10px;">
        <button id="search-button" style="font-size: 25px;">送出查詢</button>
    </div>

    <div style="position: absolute; bottom: 6px; left: 6px;">
        <!-- 返回首頁鏈結容器 -->
        <a href="admin_operation.php" style="font-size: 24px; color: black;"><i class="fas fa-home"></i> 返回前頁</a>
        <!-- 返回首頁鏈結 -->
    </div>

    <hr style="border: none; border-top: 5px solid rgba(0, 0, 0, 0.5); margin-top: 25px;">

    <div id="hotspot-details" style="display: none;">
        <!-- Hotspot详细信息 -->
        <table id="hotspot-table">
            <!-- 表格头部 -->
            <thead>
                <tr>
                    <th>HotspotID</th>
                    <th>發生地點</th>
                    <th>發生時間</th>
                    <th>是否傷亡</th>
                    <th>車輛損毀數</th>
                    <th>風速 (m/s)</th>
                    <th>溫度 (°C)</th>
                    <th>日累計雨量 (mm)</th>
                    <th>操作</th>
                </tr>
            </thead>
            <!-- 表格数据填充在这里 -->
            <tbody id="hotspot-body">
                <!-- 由PHP查询结果动态生成 -->
            </tbody>
        </table>
        <p id="update-success" style="color: red;">HS_000002 修改成功！</p>
    </div>

    <script>
        // 使用jQuery处理查询按钮的点击事件
        $('#search-button').click(function() {
            var hotspotId = $('#hotspot-id').val();
            $.post('search_hotspot.php', {
                hotspot_id: hotspotId
            }, function(data) {
                // 假设返回的数据是一个包含Hotspot详细信息的JSON对象
                var hotspotDetails = data.hotspotDetails;

                // 填充Hotspot详细信息
                $('#hotspot-body').html('');
                $('#hotspot-body').append('<tr>' +
                    '<td>' + hotspotDetails.HotspotID + '</td>' +
                    '<td>' + hotspotDetails.Location + '</td>' +
                    '<td>' + hotspotDetails.Timestamp + '</td>' +
                    '<td>' + hotspotDetails.Casualties + '</td>' +
                    '<td>' + hotspotDetails.VehicleDamage + '</td>' +
                    '<td>' + hotspotDetails.WindSpeed + '</td>' +
                    '<td>' + hotspotDetails.Temperature + '</td>' +
                    '<td>' + hotspotDetails.Rainfall + '</td>' +
                    '<td><button>編輯</button></td>' +
                    '</tr>');

                // 显示Hotspot详细信息
                $('#hotspot-details').show();
            }, 'json');
        });
    </script>
</body>

</html>

<?php
// 假设已经建立了数据库连接
$db = new PDO('pgsql:host=localhost;dbname=Test6', 'postgres', '12345');

// 从POST请求中获取HotspotID
$hotspotId = $_POST['hotspot_id'];

// 查询Hotspot详细信息
$query = $db->prepare("SELECT * FROM hotspots WHERE hotspot_id = ?");
$query->execute([$hotspotId]);
$hotspotDetails = $query->fetch(PDO::FETCH_ASSOC);

// 返回JSON数据
echo json_encode(['hotspotDetails' => $hotspotDetails]);
?>