<!DOCTYPE html>
<html lang="zh-Hant">

<head>
    <meta charset="UTF-8">
    <title>交通氣象資料管理</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 引入CSS樣式 -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h2 style="position: absolute; top: 6px; left: 10px; font-size: 30px;">交通氣象資料管理 </h2>
    <div id="navbar">
        <!-- Navbar content -->
    </div>

    <div id="search-section" style="text-align: center; margin-top: 150px;">
        <label for="hotspot-id" style="font-size: 25px;">輸入HotspotID查詢：</label>
        <input type="text" id="hotspot-id" name="hotspot-id" style="font-size: 25px; margin-right: 10px;">
        <button id="search-button" style="font-size: 25px;">送出查詢</button>
    </div>

    <div style="position: absolute; bottom: 6px; left: 6px;">
        <a href="admin_operation.php" style="font-size: 24px; color: black;"><i class="fas fa-home"></i> 返回前頁</a>
    </div>

    <hr style="border: none; border-top: 5px solid rgba(0, 0, 0, 0.5); margin-top: 25px;">

    <div id="hotspot-details" style="display: none;">
        <table id="hotspot-table">
            <thead>
                <tr>
                    <th>HotspotID</th>
                    <th>發生地點</th>
                    <th>發生時間</th>
                    <th>是否傷亡</th>
                    <th>車輛損毀數</th>
                    <th>風速 (m/s)</th>
                    <th>溫度 (°C)</th>
                    <th>日累計雨量 (mm)</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody id="hotspot-body">
                <!-- 由PHP查詢結果動態生成 -->
            </tbody>
        </table>
        <p id="update-success" style="color: red; display: none;">HS_000002 修改成功！</p>
    </div>

    <script>
        document.getElementById('search-button').addEventListener('click', function() {
            var hotspotId = document.getElementById('hotspot-id').value;
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'search_hotspot.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (this.status >= 200 && this.status < 400) {
                    var data = JSON.parse(this.response);
                    if (data && data.hotspotDetails) {
                        var hotspotDetails = data.hotspotDetails;
                        var tbody = document.getElementById('hotspot-body');
                        tbody.innerHTML = '';
                        var tr = document.createElement('tr');
                        tr.innerHTML = '<td>' + hotspotDetails.HotspotID + '</td>' +
                            '<td>' + hotspotDetails.Location + '</td>' +
                            '<td>' + hotspotDetails.Timestamp + '</td>' +
                            '<td>' + hotspotDetails.Casualties + '</td>' +
                            '<td>' + hotspotDetails.VehicleDamage + '</td>' +
                            '<td>' + hotspotDetails.WindSpeed + '</td>' +
                            '<td>' + hotspotDetails.Temperature + '</td>' +
                            '<td>' + hotspotDetails.Rainfall + '</td>' +
                            '<td><button>編輯</button></td>';
                        tbody.appendChild(tr);
                        document.getElementById('hotspot-details').style.display = 'block';
                    } else {
                        document.getElementById('hotspot-details').style.display = 'none';
                        alert('無法找到Hotspot信息。');
                    }
                } else {
                    alert('請求失敗，請檢查網絡連接或服務器配置。');
                }
            };
            xhr.send('hotspot_id=' + encodeURIComponent(hotspotId));
        });
    </script>
</body>

</html>

<?php
// 假設已經建立了數據庫連接
$db = new PDO('pgsql:host=localhost;dbname=Test6', 'postgres', '12345');

// 從POST請求中獲取HotspotID
$hotspotId = $_POST['hotspot_id'];

// 查詢Hotspot詳細信息
$query = $db->prepare("SELECT * FROM hotspots WHERE hotspot_id = ?");
$query->execute([$hotspotId]);
$hotspotDetails = $query->fetch(PDO::FETCH_ASSOC);

// 返回JSON數據
echo json_encode(['hotspotDetails' => $hotspotDetails]);
?>