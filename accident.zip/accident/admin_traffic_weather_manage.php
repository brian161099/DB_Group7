<!DOCTYPE html>
<html lang="zh-Hant">

<head>
    <meta charset="UTF-8">
    <title>交通氣象資料管理</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 引入CSS樣式 -->
    <link rel="stylesheet" href="style.css">
    <style>
        #results-table {
            border-collapse: collapse;
            margin: 0 auto;
            width: 100%;
        }

        #results-table th,
        #results-table td {
            border: 1px solid black;
            padding: 16px;
            text-align: center;
            width: calc(100% / 8);
        }
    </style>
</head>

<body>
    <h2 style="position: absolute; top: 6px; left: 10px; font-size: 30px;">交通氣象資料管理 </h2>

    <div id="navbar">
        <div id="user-info" style="position: fixed; top: 5px; right: 5px;">
            <img src="figure/admin.png" alt="User" id="user-avatar" style="display: block; width: 60px; height: auto; margin: 0 auto;">
            <button onclick="window.location='index.php'" style="display: block; width: 80px; margin: 10px auto; text-align: center;">Log out</button>
        </div>
    </div>

    <div id="search-section" style="text-align: center; margin-top: 150px;">
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <label for="hotspotid" style="font-size: 25px;">輸入HotspotID查詢：</label>
            <input type="text" id="hotspotid" name="hotspotid" style="font-size: 25px; margin-right: 10px;">
            <button type="submit" id="search-button" style="font-size: 25px;">送出查詢</button>
        </form>
    </div>

    <div style="position: absolute; bottom: 6px; left: 6px;">
        <!-- 返回首頁鏈結容器 -->
        <a href="admin_operation.php" style="font-size: 24px; color: black;"><i class="fas fa-home"></i> 返回前頁</a>
        <!-- 返回首頁鏈結 -->
    </div>

    <hr style="border: none; border-top: 5px solid rgba(0, 0, 0, 0.5); margin-top: 25px;">

    <div id="results-section">
        <table id="results-table">
            <!-- 表格頭部 -->
            <thead>
                <tr>
                    <th>HotspotID</th>
                    <th>經度</th>
                    <th>緯度</th>
                    <th>發生時間</th>
                    <th>被確認次數</th>
                    <th>風速 (m/s)</th>
                    <th>溫度 (°C)</th>
                    <th>日累積雨量 (mm)</th>
                    <th>編輯</th>
                </tr>
            </thead>
            <!-- 表格數據填充在這裡 -->
            <tbody id="table-body">
                <!-- 由PHP查詢結果動態生成 -->

            </tbody>
        </table>
    </div>

    <style>
        /* 合併的CSS樣式 */
        #results-table {
            border-collapse: collapse;
            margin: 0 auto;
            width: 100%;
            /* 需要根據實際情況調整 */
        }

        #results-table th,
        #results-table td {
            border: 1px solid black;
            padding: 16px;
            text-align: center;
            width: calc(100% / 9);
        }
    </style>

</body>

</html>

<?php
session_start();

$host = 'localhost';
$db   = 'Test6';
$user = 'postgres';
$pass = '12345';
$port = '5433';

$dsn = "pgsql:host=$host;port=$port;dbname=$db;";

try {
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['hotspotid'])) {
        $hotspotId = $_POST['hotspotid'];
        $query = $pdo->prepare("SELECT * FROM hotspot WHERE hotspotid = ?");
        $query->execute([$hotspotId]);
        $results = $query->fetchAll(PDO::FETCH_ASSOC);

        echo "<script>document.getElementById('table-body').innerHTML = '';</script>"; // 清空表格內容
        foreach ($results as $row) {
            echo "<script>document.getElementById('table-body').innerHTML += '<tr>";
            echo "<td>{$row['hotspotid']}</td>";
            echo "<td>{$row['userid']}</td>";
            echo "<td>{$row['critical']}</td>";
            echo "<td>{$row['timestamp']}</td>";
            echo "<td>{$row['locationx']}</td>";
            echo "<td>{$row['locationy']}</td>";
            echo "<td>{$row['roaddirection']}</td>";
            echo "<td><button class=\'delete-button\' data-id=\'{$row['hotspotid']}\'>編輯</button></td>";
            echo "</tr>';</script>";
        }
    }
} catch (PDOException $e) {
    die("连接失败: " . $e->getMessage());
}
?>

<script>
    // 這裡是JavaScript代碼
    // 用於處理刪除按鈕的點擊事件
    // 以及表格的動態生成
    document.addEventListener('DOMContentLoaded', function() {
        // 為刪除按鈕添加點擊事件
        document.querySelectorAll('.delete-button').forEach(button => {
            button.onclick = function() {
                // 獲取HotspotID
                const hotspotId = button.dataset.id;

                // 發送POST請求
                const request = new XMLHttpRequest();
                request.open('POST', 'admin_accident_manage_delete.php');
                request.onload = () => {
                    // 獲取伺服器響應
                    const response = request.responseText;

                    // 處理伺服器響應
                    if (response === 'success') {
                        // 刪除成功，刷新頁面
                        window.location.reload();
                    } else {
                        // 刪除失敗，提示用戶
                        alert(response);
                    }
                }

                // 將HotspotID作為參數發送
                const data = new FormData();
                data.append('hotspotid', hotspotId);

                // 發送POST請求
                request.send(data);
            }
        });
    });