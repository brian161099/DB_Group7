<!DOCTYPE html>
<html lang="zh-Hant">

<head>
    <meta charset="UTF-8">
    <title>使用者管理</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 引入CSS樣式 -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h2 style="position: absolute; top: 6px; left: 10px; font-size: 30px;">使用者管理 </h2>
    <div id="navbar">
        <div id="user-info" style="position: fixed; top: 5px; right: 5px;">
            <img src="figure/admin.png" alt="User" id="user-avatar" style="display: block; width: 60px; height: auto; margin: 0 auto;">
            <button onclick="window.location='index.php'" style="display: block; width: 80px; margin: 10px auto; text-align: center;">Log out</button>
        </div>
    </div>

    <div id="search-section" style="text-align: center; margin-top: 150px;">
        <label for="user-id" style="font-size: 25px;">輸入UserID查詢：</label>
        <input type="text" id="user-id" name="user-id" style="font-size: 25px; margin-right: 10px;">
        <button id="search-button" style="font-size: 25px;">送出查詢</button>
    </div>

    <div style="position: absolute; bottom: 6px; left: 6px;">
        <!-- 返回首頁鏈結容器 -->
        <a href="admin_operation.php" style="font-size: 24px; color: black;"><i class="fas fa-home"></i> 返回前頁</a>
        <!-- 返回首頁鏈結 -->
    </div>

    <hr style="border: none; border-top: 5px solid rgba(0, 0, 0, 0.5); margin-top: 25px;">

    <div id="user-details" style="display: none;">
        <!-- 用户详细信息 -->
        <table id="user-table">
            <!-- 表格头部 -->
            <thead>
                <tr>
                    <th>UserID</th>
                    <th>UserName</th>
                    <th>UserPassword</th>
                    <th>UserType</th>
                    <th>Status</th>
                    <th>操作</th>
                </tr>
            </thead>
            <!-- 表格数据填充在这里 -->
            <tbody id="user-body">
                <!-- 由PHP查询结果动态生成 -->
            </tbody>
        </table>

        <!-- 用户活动记录 -->
        <table id="activity-table">
            <!-- 表格头部 -->
            <thead>
                <tr>
                    <th>UserID</th>
                    <th>Type</th>
                    <th>HotspotID</th>
                    <th>Timestamp</th>
                </tr>
            </thead>
            <!-- 表格数据填充在这里 -->
            <tbody id="activity-body">
                <!-- 由PHP查询结果动态生成 -->
            </tbody>
        </table>
    </div>

    <script>
        // 處理查詢按鈕的點擊事件
        document.getElementById('search-button').addEventListener('click', function() {
            var userId = document.getElementById('user-id').value;
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'search_user.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (this.status >= 200 && this.status < 400) {
                    // 解析返回的JSON數據
                    var data = JSON.parse(this.response);
                    if (data && data.userDetails && data.userActivities) {
                        // 填充用戶詳細信息和活動記錄
                        populateUserDetails(data.userDetails);
                        populateUserActivities(data.userActivities);

                        // 顯示用戶詳細信息和活動記錄
                        document.getElementById('user-details').style.display = 'block';
                    } else {
                        // 處理無效或空數據
                        document.getElementById('user-details').style.display = 'none';
                        alert('無法找到用戶信息或用戶活動記錄。');
                    }
                } else {
                    // 處理請求失敗情況
                    alert('請求失敗，請檢查網絡連接或服務器配置。');
                }
            };
            xhr.send('user_id=' + encodeURIComponent(userId));
        });

        function populateUserDetails(userDetails) {
            var userBody = document.getElementById('user-body');
            userBody.innerHTML = ''; // 清空現有內容
            var tr = document.createElement('tr');
            tr.innerHTML = '<td>' + userDetails.UserID + '</td>' +
                '<td>' + userDetails.UserName + '</td>' +
                '<td>' + userDetails.UserPassword + '</td>' +
                '<td>' + userDetails.UserType + '</td>' +
                '<td>' + userDetails.Status + '</td>' +
                '<td><button>修改</button></td>';
            userBody.appendChild(tr);
        }

        function populateUserActivities(userActivities) {
            var activityBody = document.getElementById('activity-body');
            activityBody.innerHTML = ''; // 清空現有內容
            userActivities.forEach(function(activity) {
                var tr = document.createElement('tr');
                tr.innerHTML = '<td>' + activity.UserID + '</td>' +
                    '<td>' + activity.Type + '</td>' +
                    '<td>' + activity.HotspotID + '</td>' +
                    '<td>' + activity.Timestamp + '</td>';
                activityBody.appendChild(tr);
            });
        }
    </script>
</body>

</html>

<?php
// 假設已經建立了數據庫連接
$db = new PDO('pgsql:host=localhost;dbname=Test6', 'postgres', '12345');

// 從POST請求中獲取UserID
$userId = $_POST['user_id'];

// 查詢用戶詳細信息
$userQuery = $db->prepare("SELECT * FROM users WHERE user_id = ?");
$userQuery->execute([$userId]);
$userDetails = $userQuery->fetch(PDO::FETCH_ASSOC);

// 查詢用戶活動記錄
$activityQuery = $db->prepare("SELECT * FROM activities WHERE user_id = ?");
$activityQuery->execute([$userId]);
$userActivities = $activityQuery->fetchAll(PDO::FETCH_ASSOC);

// 返回JSON數據
echo json_encode(['userDetails' => $userDetails, 'userActivities' => $userActivities]);
?>