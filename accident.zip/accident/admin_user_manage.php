<!DOCTYPE html>
<html lang="zh-Hant">

<head>
    <meta charset="UTF-8">
    <title>使用者管理</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 引入CSS樣式 -->
    <link rel="stylesheet" href="style.css">
    <!-- 引入jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <div id="header">
        <h2>使用者管理</h2>
        <div id="user-info">
            <span>DebbieWu</span>
            <button onclick="window.location='index.php'">Log out</button>
        </div>
    </div>

    <div id="search-section">
        <label for="user-id">輸入UserID查詢：</label>
        <input type="text" id="user-id" name="user-id">
        <button id="search-button">查詢</button>
    </div>

    <div id="user-details" style="display: none;">
        <!-- 用户详细信息 -->
        <table id="user-table">
            <!-- 表格头部 -->
            <thead>
                <tr>
                    <th>UserID</th>
                    <th>UserName</th>
                    <th>UserPassword</th>
                    <th>UserType</th>
                    <th>Status</th>
                    <th>操作</th>
                </tr>
            </thead>
            <!-- 表格数据填充在这里 -->
            <tbody id="user-body">
                <!-- 由PHP查询结果动态生成 -->
            </tbody>
        </table>

        <!-- 用户活动记录 -->
        <table id="activity-table">
            <!-- 表格头部 -->
            <thead>
                <tr>
                    <th>UserID</th>
                    <th>Type</th>
                    <th>HotspotID</th>
                    <th>Timestamp</th>
                </tr>
            </thead>
            <!-- 表格数据填充在这里 -->
            <tbody id="activity-body">
                <!-- 由PHP查询结果动态生成 -->
            </tbody>
        </table>
    </div>

    <script>
        // 使用jQuery处理查询按钮的点击事件
        $('#search-button').click(function() {
            var userId = $('#user-id').val();
            $.post('search_user.php', {
                user_id: userId
            }, function(data) {
                // 假设返回的数据是一个包含用户详细信息和活动记录的JSON对象
                var userDetails = data.userDetails;
                var userActivities = data.userActivities;

                // 填充用户详细信息
                $('#user-body').html('');
                $('#user-body').append('<tr>' +
                    '<td>' + userDetails.UserID + '</td>' +
                    '<td>' + userDetails.UserName + '</td>' +
                    '<td>' + userDetails.UserPassword + '</td>' +
                    '<td>' + userDetails.UserType + '</td>' +
                    '<td>' + userDetails.Status + '</td>' +
                    '<td><button>修改</button></td>' +
                    '</tr>');

                // 填充用户活动记录
                $('#activity-body').html('');
                $.each(userActivities, function(index, activity) {
                    $('#activity-body').append('<tr>' +
                        '<td>' + activity.UserID + '</td>' +
                        '<td>' + activity.Type + '</td>' +
                        '<td>' + activity.HotspotID + '</td>' +
                        '<td>' + activity.Timestamp + '</td>' +
                        '</tr>');
                });

                // 显示用户详细信息和活动记录
                $('#user-details').show();
            }, 'json');
        });
    </script>
</body>

</html>


<?php
// 假设已经建立了数据库连接
$db = new PDO('pgsql:host=localhost;dbname=Test6', 'postgres', '12345');

// 从POST请求中获取UserID
$userId = $_POST['user_id'];

// 查询用户详细信息
$userQuery = $db->prepare("SELECT * FROM users WHERE user_id = ?");
$userQuery->execute([$userId]);
$userDetails = $userQuery->fetch(PDO::FETCH_ASSOC);

// 查询用户活动记录
$activityQuery = $db->prepare("SELECT * FROM activities WHERE user_id = ?");
$activityQuery->execute([$userId]);
$userActivities = $activityQuery->fetchAll(PDO::FETCH_ASSOC);

// 返回JSON数据
echo json_encode(['userDetails' => $userDetails, 'userActivities' => $userActivities]);
?>