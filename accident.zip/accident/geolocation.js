document.getElementById('yesBtn').addEventListener('click', function() {
    // 使用者選擇「是」，啟動地理定位功能
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else {
        alert("Geolocation is not supported by this browser.");
    }
});

document.getElementById('noBtn').addEventListener('click', function() {
    // 使用者選擇「否」，可能需要執行的代碼
    alert("您已拒絕位置共享。");
});

function showPosition(position) {
    // 定位成功，將位置資訊發送到服務器
    var lat = position.coords.latitude;
    var lon = position.coords.longitude;
    // 使用 AJAX 發送數據，這裡只是示意
    // 實際代碼中，您需要使用 AJAX 發送數據到一個 PHP 文件
}

function showError(error) {
    switch(error.code) {
        case error.PERMISSION_DENIED:
            alert("User denied the request for Geolocation.");
            break;
        case error.POSITION_UNAVAILABLE:
            alert("Location information is unavailable.");
            break;
        case error.TIMEOUT:
            alert("The request to get user location timed out.");
            break;
        case error.UNKNOWN_ERROR:
            alert("An unknown error occurred.");
            break;
    }
}
