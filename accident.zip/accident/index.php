<!DOCTYPE html>
<!-- 指定文檔為HTML5 -->
<html lang="zh-Hant">
<!-- 開始HTML文檔，設定語言為繁體中文 -->

<head>
    <!-- 頭部標籤，包含關於文檔的元數據 -->
    <meta charset="UTF-8">
    <!-- 設置字符編碼為UTF-8 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 為移動設備設置視口，確保頁面在不同裝置上正確顯示 -->
    <title>首頁登入</title>
    <!-- 設置網頁標題為“登錄界面” -->
    <link rel="stylesheet" href="styles.css">
    <!-- 引入外部CSS文件，用於樣式設計 -->
</head>

<body>
    <!-- 網頁主體部分 -->
    <div class="login-container">
        <!-- 登錄容器，包裹整個登錄區域的內容 -->
        <h2 style="position: absolute; top: 6px; left: 6px; font-size: 35px;">您好，歡迎使用即時國道事故查詢系統～ </h2>
        <!-- 標題，使用內聯樣式定位在頁面的特定位置 -->
        <div class="role-selection">
            <!-- 角色選擇區域，用於顯示不同的登錄選項 -->
            <div class="role" id="user">
                <!-- 單個角色選項，此處為“user” -->
                <img src="figure\user.png" alt="USER">
                <!-- 用戶圖標 -->
                <button class="right-align" style="margin-left: 8px;" onclick="redirectToLogin('user')">USER</button>
                <!-- 用戶登錄按鈕，點擊時觸發JavaScript函數 -->
            </div>

            <div class="role" id="viewer">
                <!-- 角色選項“viewer” -->
                <img src="figure\viewer.png" alt="VIEWER">
                <!-- 觀察者圖標 -->
                <button class="right-align" style="margin-left: 8px;" onclick="redirectToLogin('viewer')">VIEWER</button>
                <!-- 觀察者登錄按鈕 -->
            </div>

            <div class="role" id="admin">
                <!-- 角色選項“admin” -->
                <img src="figure\admin.png" alt="ADMIN">
                <!-- 管理員圖標 -->
                <button class="right-align" style="margin-left: 8px;" onclick="redirectToLogin('admin')">ADMIN</button>
                <!-- 管理員登錄按鈕 -->
            </div>
        </div>

        <div class="signup-link" style="text-align: center; font-size: 20px;">
            <a href="signup.php">Sign Up</a>
            <!-- 註冊鏈接 -->
        </div>

        <script>
            function redirectToLogin(role) {
                // Redirect to the login page based on the selected role
                if (role === 'user') {
                    window.location.href = 'login_user.php';
                } else if (role === 'viewer') {
                    window.location.href = 'login_viewer.php';
                } else if (role === 'admin') {
                    window.location.href = 'login_admin.php';
                }
            }
        </script>




    </div>
    <!-- 結束登錄容器 -->

</body>
<!-- 結束網頁主體部分 -->

</html>
<!-- 結束HTML文檔 -->