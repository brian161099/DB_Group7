<!DOCTYPE html>
<!-- 定義文檔類型為HTML5 -->
<html lang="zh-Hant">
<!-- 指定頁面語言為繁體中文 -->

<head>
    <meta charset="UTF-8">
    <!-- 設定字符編碼為UTF-8 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 設定視口屬性，確保在不同設備上正確顯示 -->
    <title>管理者登錄</title>
    <!-- 定義網頁標題 -->
    <link rel="stylesheet" href="styles.css">
    <!-- 引入外部CSS樣式表 -->
</head>

<body>
    <div class="login-container">
        <!-- 登錄容器 -->
        <h2 style="position: absolute; top: 6px; left: 6px; font-size: 35px;">您好，歡迎使用即時國道事故查詢系統～ </h2>
        <!-- 顯示歡迎信息，使用內聯樣式定位 -->

        <div class="login-form">
            <!-- 登錄表單容器 -->
            <div style="display: flex;  flex-direction: column; align-items: center;">
                <!-- 用戶圖像和標題的容器 -->
                <img src="figure\admin.png" alt="ADMIN" style="width: 100px; height: 100px;">
                <!-- 用戶圖像 -->
                <h3 style="font-size: 24px; margin-left: 10px;">ADMIN</h3>
                <!-- 用戶標題 -->
            </div>
            <form action="login_admin.php" method="post">
                <!-- 登錄表單，提交時將數據發送到login_admin.php -->
                <div style="display: flex; flex-direction: column; align-items: center;">
                    <!-- 用戶ID輸入欄位 -->
                    <div style="margin-bottom: 10px;">
                        <label for="userid" style="font-size: 20px;">UserID:</label>
                        <input type="text" id="userid" name="userid" required style="width: 300px; height: 30px;">
                        <!-- 輸入框 -->
                    </div>
                    <div style="margin-bottom: 10px;">
                        <!-- 密碼輸入欄位 -->
                        <label for="password" style="font-size: 20px;">Password:</label>
                        <input type="password" id="password" name="password" required style="width: 300px; height: 30px;">
                        <!-- 輸入框 -->
                    </div>
                    <div>
                        <!-- 提交按鈕 -->
                        <input type="submit" value="登入" style="font-size: 24px;">
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php if (isset($_SESSION['error'])) : ?>
        <!-- 檢查SESSION中是否有錯誤訊息 -->
        <div class="error-message">
            <!-- 顯示錯誤訊息的容器 -->
            <?php
            echo $_SESSION['error'];
            unset($_SESSION['error']);
            ?>
            <!-- 顯示並清除錯誤訊息 -->
        </div>
    <?php endif; ?>

    <div style="position: absolute; bottom: 6px; left: 6px;">
        <!-- 返回首頁鏈結容器 -->
        <a href="index.php" style="font-size: 24px; color: black;"><i class="fas fa-home"></i> 返回首頁</a>
        <!-- 返回首頁鏈結 -->
    </div>

</body>

</html>

<?php
session_start();
// 啟動新的或繼續現有的會話

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 檢查是否是POST請求

    // 連接到PostgreSQL資料庫
    $dbconn = pg_connect("host=localhost dbname=Test6 user=postgres password=12345 port=5433")
        or die('無法連接到資料庫：' . pg_last_error());

    // 使用pg_escape_string防止SQL注入
    $userid = pg_escape_string($dbconn, $_POST['userid']);
    $password = pg_escape_string($dbconn, $_POST['password']);

    // 構建查詢語句
    $query = "SELECT * FROM users WHERE userid = '$userid' AND userpassword = '$password'";

    // 執行查詢
    $result = pg_query($dbconn, $query);

    if (pg_num_rows($result) == 1) {
        // 檢查返回的行數是否為1，即用戶存在且密碼正確
        $_SESSION['login_admin'] = $userid;
        // 設置會話變量
        header("location: admin_operation.php");
        // 重定向到操作界面
    } else {
        // 登錄失敗
        $_SESSION['error'] = 'UserID或Password不正確，請再試一次。';
        // 設置錯誤信息
        header("location: login_admin.php");
        // 重定向回登錄頁面
    }

    pg_close($dbconn);
    // 關閉資料庫連接
}
?>