<!DOCTYPE html>
<html lang="zh-Hant">

<head>
    <meta charset="UTF-8">
    <title>註冊新用戶</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 引入CSS樣式，需要根据实际情况编写 -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="signup-container">
        <h1>Sign up</h1>
        <div class="user-icon">
            <img src="user_avatar.png" alt="User" class="user-avatar">
            <span>USER</span>
        </div>
        <form action="register.php" method="post">
            <label for="username">輸入 Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">輸入 Password:</label>
            <input type="password" id="password" name="password" required>

            <label for="confirm-password">再次輸入 Password:</label>
            <input type="password" id="confirm-password" name="confirm_password" required>

            <button type="submit">確定</button>
        </form>
        <a href="index.php">← 返回主頁面</a>
    </div>
</body>

</html>

<?php
// 检测是否有POST请求
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取用户提交的数据
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // 简单的验证
    if (empty($username) || empty($password)) {
        die('Username or password cannot be empty');
    }

    if ($password !== $confirm_password) {
        die('Passwords do not match');
    }

    // 这里应该有更多的验证和密码加密处理...

    // 假设已经建立了数据库连接
    $db = new PDO('pgsql:host=localhost;dbname=Test6', 'postgres', '12345');

    // 插入新用户数据到数据库
    $query = $db->prepare("INSERT INTO users (username, password) VALUES (?, ?)");

    // 在实际应用中，应使用密码哈希函数
    $passwordHashed = password_hash($password, PASSWORD_DEFAULT);

    $query->execute([$username, $passwordHashed]);

    if ($query) {
        echo "User registered successfully";
    } else {
        echo "User registration failed";
    }
}
?>