<!DOCTYPE html>
<html lang="zh-Hant">

<head>
    <meta charset="UTF-8">
    <title>註冊成功</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="registration-success-container">
        <h1>Sign up</h1>
        <p>註冊成功！</p>
        <div class="user-details">
            <p>您的 UserID 為 <strong>U0302</strong></p>
            <p>Username: SereneChen</p>
            <p>Password: HUvjkdu57T</p>
        </div>
        <div class="note">
            <p><em>User 註冊成功後，請務必一個未來使用的 UserID</em></p>
        </div>
        <button onclick="window.location.href='index.php'">返回主頁面</button>
    </div>
</body>

</html>

<?php
// 假设这个脚本是用户提交注册表单后处理数据的脚本

// 检测是否有POST请求
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取用户提交的数据
    $username = $_POST['username'];
    $password = $_POST['password'];

    // 这里应该有更多的验证和密码加密处理...

    // 假设已经建立了数据库连接
    $db = new PDO('pgsql:host=localhost;dbname=your_database', 'username', 'password');

    // 插入新用户数据到数据库
    $query = $db->prepare("INSERT INTO users (username, password) VALUES (?, ?)");

    // 在实际应用中，应使用密码哈希函数
    $passwordHashed = password_hash($password, PASSWORD_DEFAULT);

    $query->execute([$username, $passwordHashed]);

    // 假设我们通过某种方式生成了一个UserID
    $userID = 'U0302'; // 这应该是动态生成的

    if ($query) {
        // 注册成功，显示确认页面
        header('Location: registration_success.html');
    } else {
        echo "User registration failed";
    }
} else {
    // 如果不是POST请求，则重定向到注册表单页面
    header('Location: signup.html');
}
?>