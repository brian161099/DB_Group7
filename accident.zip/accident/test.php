<?php
$host = 'localhost';  // PostgreSQL 服务器地址
$db   = 'Test6';      // 数据库名
$user = 'postgres';  // PostgreSQL 用户名
$pass = '12345';  // PostgreSQL 密码
$port = '5433';       // PostgreSQL 端口号，默认是 5432

// 创建连接
$conn = pg_connect("host=$host dbname=$db user=$user password=$pass port=$port");

// 检查连接
if (!$conn) {
    echo "错误：无法连接到数据库。\n";
    exit;
} else {
    echo "成功：已连接到数据库。\n";
}

// 这里可以添加更多的数据库操作代码

// 关闭连接
pg_close($conn);
