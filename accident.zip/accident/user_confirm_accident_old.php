<!DOCTYPE html>
<html lang="zh-TW">

<head>
    <meta charset="UTF-8">
    <title>位置共享請求</title>
</head>

<body>
    <div id="userInfo">
        <!-- 使用者資訊，使用 PHP 動態生成 -->
        <?php include 'user_info.php'; ?>
    </div>

    <div id="locationRequest">
        <h2>確認您的位置</h2>
        <p>您的位置：25°11'N 121°73'E</p>
        <p>事故定位服務？</p>
        <button id="yesBtn">是</button>
        <button id="noBtn">否</button>
    </div>

    <script src="geolocation.js"></script>
</body>

</html>

<?php
// 假設用戶已經登入系統
$userName = "SereneChen"; // 這個值通常是從資料庫或會話中獲取的

echo "<div id='userStatus'>";
echo "<p>用戶： " . htmlspecialchars($userName) . "</p>";
echo "<a href='logout.php'>登出</a>";
echo "</div>";
?>