<!DOCTYPE html>
<html lang="zh-TW">

<head>
    <meta charset="UTF-8">
    <title>歡迎頁面</title>
    <style>
        /* 在這裡添加 CSS 樣式 */
        body {
            text-align: center;
            font-family: 'Arial', sans-serif;
        }

        #logoutButton {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
    </style>
</head>

<body>
    <h1>歡迎成功！</h1>
    <form action="logout.php" method="post">
        <button type="submit" id="logoutButton">回到主頁面</button>
    </form>

    <div id="userInfo">
        <!-- 使用者資訊，使用 PHP 動態生成 -->
        <?php include 'user_info.php'; ?>
    </div>
</body>

</html><?php
        // 假設用戶已經登入系統
        $userName = "SereneChen"; // 這個值通常是從資料庫或會話中獲取的

        echo "<div id='userStatus'>";
        echo "<p>用戶： " . htmlspecialchars($userName) . "</p>";
        echo "<a href='logout.php'>登出</a>";
        echo "</div>";
        ?>

<?php
// 這裡會處理登出邏輯
session_start();
session_destroy(); // 銷毀所有的會話
header('Location: index.html'); // 重定向回首頁
exit();
?>