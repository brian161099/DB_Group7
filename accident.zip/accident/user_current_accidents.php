<!DOCTYPE html>
<html lang="zh-TW">

<head>
    <meta charset="UTF-8">
    <title>公路事故查詢系統</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 引入CSS樣式 -->
    <link rel="stylesheet" href="style.css">
    <!-- 引入jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <h2 style="position: absolute; top: 6px; left: 10px; font-size: 30px;">當前事故熱點 </h2>
    <div id="navbar">
        <div id="user-info" style="position: fixed; top: 5px; right: 5px;">
            <img src="figure/user.png" alt="User" id="user-avatar" style="display: block; width: 60px; height: auto; margin: 0 auto;">
            <button onclick="window.location='index.php'" style="display: block; width: 80px; margin: 10px auto; text-align: center;">Log out</button>
        </div>
    </div>

    <div style="position: absolute; bottom: 6px; left: 6px;">
        <!-- 返回首頁鏈結容器 -->
        <a href="user_operation.php" style="font-size: 24px; color: black;"><i class="fas fa-home"></i> 返回前頁</a>
        <!-- 返回首頁鏈結 -->
    </div>

</body>

</html>