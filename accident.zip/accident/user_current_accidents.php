<!DOCTYPE html>
<html lang="zh-TW">

<head>
    <meta charset="UTF-8">
    <title>公路事故查詢系統</title>
</head>

<body>
    <div id="userInfo">
        <!-- 使用者資訊，使用 PHP 動態生成 -->
        <?php include 'user_info.php'; ?>
    </div>

    <div id="accidentInfo">
        <!-- 事故資訊，使用 PHP 動態生成 -->
        <?php include 'accident_info.php'; ?>
    </div>

    <div id="map">
        <!-- 地圖區域 -->
        <!-- 此處將嵌入 Google 地圖 API，顯示事故位置 -->
    </div>

    <script>
        // 此處可以放置用於與 Google Maps API 互動的 JavaScript 代碼
    </script>
</body>

</html>


<?php
// 假設已經有一個用戶登入系統
$userName = "SereneChen"; // 通常這會從資料庫或會話中獲取

echo "<p>歡迎, " . htmlspecialchars($userName) . " <a href='logout.php'>登出</a></p>";
?>
<?php
// 假設從資料庫中獲取了事故資料
$accidentData = [
    // 這裡填入從資料庫獲取的數據
];

foreach ($accidentData as $accident) {
    echo "<div class='accident-entry'>";
    echo "<p>發生地點：" . htmlspecialchars($accident['location']) . "</p>";
    echo "<p>發生時間：" . htmlspecialchars($accident['time']) . "</p>";
    // ... 其他資訊
    echo "</div>";
}
?>