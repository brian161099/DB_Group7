<!DOCTYPE html>
<html lang="zh-TW">

<head>
    <meta charset="UTF-8">
    <title>公路事故查詢系統</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 引入CSS樣式 -->
    <link rel="stylesheet" href="style.css">
    <!-- 引入jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <h2 style="position: absolute; top: 6px; left: 10px; font-size: 30px;">當前事故熱點 </h2>
    <div id="navbar">
        <div id="user-info" style="position: fixed; top: 5px; right: 5px;">
            <img src="figure/user.png" alt="User" id="user-avatar" style="display: block; width: 60px; height: auto; margin: 0 auto;">
            <button onclick="window.location='index.php'" style="display: block; width: 80px; margin: 10px auto; text-align: center;">Log out</button>
        </div>
    </div>

</body>

</html>

div id="userInfo">
<!-- 使用者資訊，使用 PHP 動態生成 -->
<?php include 'user_info.php'; ?>
</div>

div id="accidentInfo">
<!-- 事故資訊，使用 PHP 動態生成 -->
<?php include 'accident_info.php'; ?>
</div>

<div id="map">
    <!-- 地圖區域 -->
    <!-- 此處將嵌入 Google 地圖 API，顯示事故位置 -->
</div>

<script>
    // 此處可以放置用於與 Google Maps API 互動的 JavaScript 代碼
</script>





?php
// 假設已經有一個用戶登入系統
$userName = "SereneChen"; // 通常這會從資料庫或會話中獲取

echo "<p>歡迎, " . htmlspecialchars($userName) . " <a href='logout.php'>登出</a></p>";
?>
?php
// 假設從資料庫中獲取了事故資料
$accidentData = [
// 這裡填入從資料庫獲取的數據
];

foreach ($accidentData as $accident) {
echo "<div class='accident-entry'>";
    echo "<p>發生地點：" . htmlspecialchars($accident['location']) . "</p>";
    echo "<p>發生時間：" . htmlspecialchars($accident['time']) . "</p>";
    // ... 其他資訊
    echo "</div>";
}
?>