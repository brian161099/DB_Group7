<!DOCTYPE html>
<html lang="zh-Hant">

<head>
    <meta charset="UTF-8">
    <title>高速公路事故查詢系統</title>
    <!-- 引入CSS樣式 -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h2 style="position: absolute; top: 6px; left: 10px; font-size: 30px;">請選擇所需服務: </h2>
    <div id="navbar">
        <div id="user-info" style="float: right;">
            <img src="figure/user.png" alt="User" id="user-avatar" style="display: block; width: 60px; height: auto; margin: 0 auto;">
            <button onclick="window.location='index.php'" style="display: block; width: 80px; margin: 10px auto; text-align: center;">Log out</button>
        </div>
    </div>

    <div id="main-content" class="role-selection" style="display: flex; justify-content: center;">
        <div class="role" id="current-accidents" onclick="window.location='user_current_accidents.php';">
            <button style="margin-right: 50px; margin-top: 180px;">
                <img src="figure/hotspot_occur_now.jpg" alt="當前事故熱點">
                <p style="font-size: 20px; font-weight: bold;">當前事故熱點</p>
            </button>
        </div>
        <div class="role" id="confirm-accident" onclick="window.location='user_confirm_accident.php';">
            <button style="margin-right: 50px; margin-top: 180px;">
                <img src="figure/hotspot_report.jpg" alt="確認事故發生">
                <p style="font-size: 20px; font-weight: bold;">確認事故發生</p>
            </button>
        </div>
        <div class="role" id="query-accidents" onclick="window.location='user_query_accidents.php';">
            <button style="margin-right: 50px; margin-top: 180px;">
                <img src="figure/hotspot_check.jpg" alt="查詢事故熱點">
                <p style="font-size: 20px; font-weight: bold;">查詢事故熱點</p>
            </button>
        </div>
    </div>

    <script src="script.js"></script>
</body>

</html>