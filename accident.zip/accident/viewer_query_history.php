<!DOCTYPE html>
<html lang="zh-Hant">

<head>
    <meta charset="UTF-8">
    <title>事故數據查詢</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h2 style="position: absolute; top: 6px; left: 10px; font-size: 30px;">查詢歷史事故</h2>

    <div id="navbar">
        <div id="user-info" style="position: fixed; top: 5px; right: 5px;">
            <img src="figure/viewer.png" alt="User" id="user-avatar" style="width: 60px; height: auto; margin: 0 auto;">
            <button onclick="window.location='index.php'" style="width: 80px; margin: 10px auto; text-align: center;">Log out</button>
        </div>
    </div>

    <div id="query-section" style="text-align: center; margin-top: 150px;">
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <label for="start-time" style="font-size: 25px;">依時間查詢 起:</label>
            <input type="datetime-local" id="start-time" name="start-time" style="font-size: 25px; margin-right: 10px;">

            <label for="end-time" style="font-size: 25px;">迄:</label>
            <input type="datetime-local" id="end-time" name="end-time" style="font-size: 25px; margin-left: 10px;">

            <button type="submit" id="query-button" style="font-size: 25px;">送出查詢</button>
        </form>
    </div>

    <div style="position: absolute; bottom: 6px; left: 6px;">
        <a href="viewer_operation.php" style="font-size: 24px; color: black;"><i class="fas fa-home"></i> 返回前頁</a>
    </div>

    <hr style="border-top: 5px solid rgba(0, 0, 0, 0.5); margin-top: 25px;">

    <div id="results-section">
        <table id="results-table">
            <!-- 表格頭部 -->
            <thead>
                <tr>
                    <th>發生地點</th>
                    <th>發生時間</th>
                    <th>是否嚴重</th>
                    <th>被確認次數</th>
                    <th>風速 (m/s)</th>
                    <th>溫度 (°C)</th>
                    <th>日累積雨量 (mm)</th>
                </tr>
            </thead>
            <!-- 表格數據填充在這裡 -->
            <tbody id="table-body">
                <!-- 由PHP查詢結果動態生成 -->

            </tbody>
        </table>
    </div>

    <style>
        /* 合併的CSS樣式 */
        #results-table {
            border-collapse: collapse;
            margin: 0 auto;
            width: 100%;
            /* 需要根據實際情況調整 */
        }

        #results-table th,
        #results-table td {
            border: 1px solid black;
            padding: 16px;
            text-align: center;
            width: calc(100% / 8);
        }
    </style>
</body>

</html>

<?php
session_start();

$host = 'localhost';
$db = 'Test6';
$user = 'postgres';
$pass = '12345';
$port = '5433';
$dsn = "pgsql:host=$host;port=$port;dbname=$db;user=$user;password=$pass";

try {
    $pdo = new PDO($dsn);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $startTime = $_POST['start-time'] ?? null;
    $endTime = $_POST['end-time'] ?? null;

    if ($startTime === null || $endTime === null) {
        echo "請提供有效的時間範圍";
        exit;
    }

    $query = $pdo->prepare("SELECT 
                                h.locationx || ', ' || h.locationy AS 發生地點,
                                h.timestamp AS 發生時間,
                                h.critical AS 是否嚴重,
                                h.confirmcount AS 被確認次數,
                                w.wdsd AS 風速,
                                w.temp AS 溫度,
                                w.\"24R\" AS 日累積雨量
                            FROM 
                                hotspot h
                            CROSS JOIN 
                                geolocatingstaticinfo g
                            JOIN 
                                weatherobs w ON g.neareststationid = w.stationid
                            WHERE 
                                h.timestamp BETWEEN ? AND ?
                            ORDER BY 
                                POWER(h.locationx - g.locationx, 2) + POWER(h.locationy - g.locationy, 2)
                            LIMIT 1");

    $query->execute([$startTime, $endTime]);
    $results = $query->fetchAll(PDO::FETCH_ASSOC);

    echo "<script>document.getElementById('table-body').innerHTML = '';</script>"; // 清空表格內容
    foreach ($results as $row) {
        echo "<script>document.getElementById('table-body').innerHTML += '<tr>";
        echo "<td>{$row['發生地點']}</td>";
        echo "<td>{$row['發生時間']}</td>";
        echo "<td>{$row['是否嚴重']}</td>";
        echo "<td>{$row['被確認次數']}</td>";
        echo "<td>{$row['風速']}</td>";
        echo "<td>{$row['溫度']}</td>";
        echo "<td>{$row['日累積雨量']}</td>";
        echo "</tr>';</script>";
    }
} catch (PDOException $e) {
    echo "資料庫連接失敗: " . $e->getMessage();
}
?>