<!DOCTYPE html>
<html lang="zh-Hant">

<head>
    <meta charset="UTF-8">
    <title>事故數據查詢</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 引入CSS樣式 -->
    <link rel="stylesheet" href="style.css">
    <!-- 引入jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>


<body>
    <h2 style="position: absolute; top: 6px; left: 10px; font-size: 30px;">查詢歷史事故 </h2>
    <div id="navbar">
        <div id="user-info" style="position: fixed; top: 5px; right: 5px;">
            <img src="figure/viewer.png" alt="User" id="user-avatar" style="display: block; width: 60px; height: auto; margin: 0 auto;">
            <button onclick="window.location='index.php'" style="display: block; width: 80px; margin: 10px auto; text-align: center;">Log out</button>
        </div>
    </div>

    <div id="query-section" style="text-align: center; margin-top: 150px;">
        <label for="start-time" style="font-size: 25px;">依時間查詢 起:</label>
        <input type="datetime-local" id="start-time" name="start-time" style="font-size: 25px; margin-right: 10px;">

        <label for="end-time" style="font-size: 25px;">迄:</label>
        <input type="datetime-local" id="end-time" name="end-time" style="font-size: 25px; margin-left: 10px;">

        <button id="query-button" style="font-size: 25px;">送出查詢</button>
    </div>


    <div style="position: absolute; bottom: 6px; left: 6px;">
        <!-- 返回首頁鏈結容器 -->
        <a href="viewer_operation.php" style="font-size: 24px; color: black;"><i class="fas fa-home"></i> 返回前頁</a>
        <!-- 返回首頁鏈結 -->
    </div>

    <hr style="border: none; border-top: 5px solid rgba(0, 0, 0, 0.5); margin-top: 25px;">

    <table id="results-table" style="border-collapse: collapse; width: 100%;">
        <!-- 表格頭部 -->
        <thead>
            <tr>
                <th style="border: 1px solid black;">發生地點</th>
                <th style="border: 1px solid black;">發生時間</th>
                <th style="border: 1px solid black;">是否嚴重</th>
                <th style="border: 1px solid black;">被確認次數</th>
                <th style="border: 1px solid black;">風速 (m/s)</th>
                <th style="border: 1px solid black;">溫度 (°C)</th>
                <th style="border: 1px solid black;">日累計雨量 (mm)</th>
            </tr>
        </thead>
        <!-- 表格數據填充在這裡 -->
        <tbody id="table-body">
            <!-- 由PHP查詢結果動態生成 -->
        </tbody>
    </table>


    <script>
        // 使用jQuery處理查詢按鈕的點擊事件
        $('#query-button').click(function() {
            var startTime = $('#start-time').val();
            var endTime = $('#end-time').val();
            $.post('query.php', {
                start: startTime,
                end: endTime
            }, function(data) {
                $('#table-body').html(data);
            });
        });
    </script>
</body>

</html>

<?php
// 假設已經建立了資料庫連接
$db = new PDO('pgsql:host=localhost;dbname=Test6', 'postgres', '12345');

// 從POST請求中獲取時間範圍
$startTime = $_POST['start'];
$endTime = $_POST['end'];

// 計算時間間隔
$diff = strtotime($endTime) - strtotime($startTime);
$diffInDays = floor($diff / (60 * 60 * 24));

// 檢查時間間隔是否超過7天
if ($diffInDays > 7) {
    echo "時間間隔不能超過7天";
    exit;
}

// 安全地構建SQL查詢，防止SQL注入
$query = $db->prepare("SELECT * FROM accidents WHERE occurrence_time BETWEEN ? AND ?");
$query->execute([$startTime, $endTime]);

// 獲取查詢結果
$results = $query->fetchAll(PDO::FETCH_ASSOC);

// 將結果以HTML表格行的形式輸出
foreach ($results as $row) {
    echo "<tr>";
    echo "<td>{$row['location']}</td>";
    echo "<td>{$row['occurrence_time']}</td>";
    echo "<td>{$row['casualties']}</td>";
    echo "<td>{$row['vehicle_damage_count']}</td>";
    echo "<td>{$row['wind_speed']}</td>";
    echo "<td>{$row['temperature']}</td>";
    echo "<td>{$row['rainfall']}</td>";
    echo "</tr>";
}
?>